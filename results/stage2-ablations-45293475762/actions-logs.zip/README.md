Run 45293475762, attempt 1, commit a34896712d35c06946e40c9b04275f2372c4ecd3. GitHub reports success.

49 of 49 registered artifacts were archived and matched their exact GitHub byte sizes and SHA-256 digests. The archive index gives paths relative to the run directory. Per-job logs have signed query strings and credential-like values removed before storage. The log index records the stored bytes, lines and SHA-256.
