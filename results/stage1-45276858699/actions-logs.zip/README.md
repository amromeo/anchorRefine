The workflow metadata was retrieved from GitHub after completion and checked against run ID, attempt, commit and job membership. The log files contain the complete text returned by the GitHub job-log API. Signed URL query strings and credential-like values are removed before persistence. The output retains GitHub’s own secret masking. The log index records final UTF-8 size, line count, SHA-256 and whether the runner cleanup footer was present.

Run 45276858699, attempt 1, commit ec7ab5400b61ff732dec34aa6460d96bbc623ea0. Retrieved 8 of 8 job logs. Missing or unavailable job logs: none.
