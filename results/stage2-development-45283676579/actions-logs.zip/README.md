Run 45283676579, attempt 1, commit 1c914bc3448a50f5327e522525cb448bfe836cea. GitHub reports success.

49 of 49 registered artifacts were archived and matched their exact GitHub byte sizes and SHA-256 digests. The archive index gives paths relative to the run directory. Per-job logs have signed query strings and credential-like values removed before storage. The log index records the stored bytes, lines and SHA-256.
