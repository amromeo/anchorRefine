Run 45303419260, attempts 1 through 2, commit f30b88777310a7000628faf0ec92b6d7f4484bd9. GitHub reports success.

49 of 49 registered artifacts were archived and matched their exact GitHub byte sizes and SHA-256 digests. The archive index gives paths relative to the run directory. Per-job logs have signed query strings and credential-like values removed before storage. The log index records the stored bytes, lines and SHA-256.
