Run 45303419260, attempts 1 through 1, commit f30b88777310a7000628faf0ec92b6d7f4484bd9. GitHub reports failure.

47 of 47 registered artifacts were archived and matched their exact GitHub byte sizes and SHA-256 digests. The archive index gives paths relative to the run directory. Per-job logs have signed query strings and credential-like values removed before storage. The log index records the stored bytes, lines and SHA-256.
