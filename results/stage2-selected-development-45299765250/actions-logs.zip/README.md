Run 45299765250, attempt 1, commit c043917226b20929296b80cda53e0ae293968b42. GitHub reports success.

49 of 49 registered artifacts were archived and matched their exact GitHub byte sizes and SHA-256 digests. The archive index gives paths relative to the run directory. Per-job logs have signed query strings and credential-like values removed before storage. The log index records the stored bytes, lines and SHA-256.
