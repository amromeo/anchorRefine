# RIbench N = 50000

RIbench evaluateAlgorithmResults stopped at a sample-size subset plot. Native per-dataset metrics and category scores were recovered using its unchanged computePerfMeasAll and getBenchmarkResults functions. No fits were rerun.

All 1,440 datasets were evaluated with each of three methods. This is a subset evaluation, not the published full RIbench benchmark score. AnchoredRI and anchorsOnly receive simulated screened anchors; refineR receives only routine data.

Runtime below is the sum of per-fit elapsed seconds, excluding generation, installation and workflow queueing. Parallel execution wall time should be reported separately.

| Subset | Method | N | Failed | Mean absolute Z deviation | Capped mean | Fit runtime (minutes) |
|---|---|---:|---:|---:|---:|---:|
| all | anchoredRI | 1440 | 0 | 0.9572 | 0.3656 | 40.25 |
| lambda=0.432 | anchoredRI | 144 | 0 | 0.5154 | 0.2575 | 3.86 |
| all | anchorsOnly | 1440 | 0 | 0.2961 | 0.2961 | 0.47 |
| lambda=0.432 | anchorsOnly | 144 | 0 | 0.2456 | 0.2456 | 0.04 |
| all | refineR | 1440 | 0 | 0.3099 | 0.2282 | 93.61 |
| lambda=0.432 | refineR | 144 | 0 | 0.1792 | 0.1792 | 8.62 |

The uncapped metric summarizes available results; inspect failure counts with it. Capped deviations and RIbench subset scores retain RIbench conventions. FT4 is the lambda=0.432 subset. CRP uses its one-sided 95th percentile.

Stage sample size is specified above. Runtime is the sum of fit times. Source versions and native outputs are retained.
