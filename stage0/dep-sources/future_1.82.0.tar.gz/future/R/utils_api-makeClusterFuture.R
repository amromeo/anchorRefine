#' Create a Future Cluster of Stateless Workers for Parallel Processing
#'
#' _WARNING: Please note that this sets up a stateless set of cluster nodes,
#' which means that `clusterEvalQ(cl, { a <- 3.14 })` will not work.
#' The exception is `clusterEvalQ()` calls that only attach packages,
#' e.g. `clusterEvalQ(cl, library(pkg))`, which are supported.
#' Consider this a first beta version and use it with great care,
#' particularly because of the stateless nature of the cluster.
#' For now, I recommend to manually validate that you can get identical
#' results using this cluster type with what you get from using the
#' classical `parallel::makeCluster()` cluster type._
#'
#'
#' @param specs Ignored.
#' If specified, the value should equal `nbrOfWorkers()` (default).
#' A missing value corresponds to specifying `nbrOfWorkers()`.
#' This argument exists only to support
#' `parallel::makeCluster(NA, type = future::FUTURE)`.
#'
#' @param \ldots Named arguments passed to [future::future()].
#'
#' @return
#' Returns a \pkg{parallel} `cluster` object of class `FutureCluster`.
#'
#' @examplesIf (getRversion() >= "4.4.0")
#' plan(multisession)
#' cl <- makeClusterFuture()
#'
#' parallel::clusterSetRNGStream(cl)
#'
#' y <- parallel::parLapply(cl, 11:13, function(x) {
#'   message("Process ID: ", Sys.getpid())
#'   mean(rnorm(n = x))
#' })
#' str(y)
#'
#' ## Attach the 'tools' package for all future parallel tasks
#' parallel::clusterEvalQ(cl, library(tools))
#'
#' y <- parallel::parLapply(cl, c("a.txt", "b.R"), function(x) {
#'   file_ext(x)
#' })
#' str(y)
#'
#' plan(sequential)
#'
#' @section Future Clusters are Stateless:
#' Traditionally, a cluster nodes has a one-to-one mapping to a cluster
#' worker process. For example, `cl <- makeCluster(2, type = "PSOCK")`
#' launches two parallel worker processes in the background, where
#' cluster node `cl[[1]]` maps to worker #1 and node `cl[[2]]` to
#' worker #2, and that never changes through the lifespan of these
#' workers. This one-to-one mapping allows for deterministic
#' configuration of workers. For examples, some code may assign globals
#' with values specific to each worker, e.g.
#' `clusterEvalQ(cl[1], { a <- 3.14 })` and
#' `clusterEvalQ(cl[2], { a <- 2.71 })`.
#'
#' In contrast, there is no one-to-one mapping between cluster nodes
#' and the parallel workers when using a future cluster. This is because
#' we cannot make assumptions on where are parallel task will be
#' processed. Where a parallel task is processes is up to the future
#' backend to decide - some backends do this deterministically, whereas
#' others other resolves task at the first available worker. Also, the
#' worker processes might be _transient_ for some future backends, i.e.
#' the only exist for the life-span of the parallel task and then
#' terminates.
#'
#' Because of this, one must not rely in node-specific behaviors,
#' because that concept does not make sense with a future cluster.
#' To protect against this, any attempt to address a subset of future
#' cluster nodes, results in an error, e.g. `clusterEvalQ(cl[1], ...)`,
#' `clusterEvalQ(cl[1:2], ...)`, and `clusterEvalQ(cl[2:1], ...)` in
#' the above example will all give an error.
#'
#' Exceptions to the latter limitation are `clusterSetRNGStream()`,
#' `clusterExport()`, and `clusterEvalQ()` calls that only attach
#' packages, which can be safely used with future clusters.
#' See below for more details.
#'
#' @section clusterSetRNGStream:
## [parallel::clusterSetRNGStream()] results in
## \code{\link[parallel:RngStream]{parallel::clusterSetRNGStream()}}, which
## causes Rd2md::render_refman() to produce an error /HB 2025-12-23
#' \code{\link[parallel:clusterSetRNGStream]{parallel::clusterSetRNGStream()}}
#' distributes "L'Ecuyer-CMRG" RNG
#' streams to the cluster nodes, which record them such that the next
#' round of futures will use them. When used, the RNG state after the
#' futures are resolved are recorded accordingly, such that the next
#' round again of future will use those, and so on. This strategy
#' makes sure `clusterSetRNGStream()` has the expected effect although
#' futures are stateless.
#'
#' @section clusterExport:
#' [parallel::clusterExport()] assign values to the cluster nodes.
#' Specifically, these values are recorded and are used as globals
#' for all futures created there on.
#'
#' @section clusterEvalQ:
#' [parallel::clusterEvalQ()] is supported only for expressions that
#' attach packages and nothing else, e.g.
#'
#'  * `clusterEvalQ(cl, library(pkg))`
#'  * `clusterEvalQ(cl, { library(pkg1); library(pkg2) })`
#'  * `clusterEvalQ(cl, require("pkg"))`
#'  * `clusterEvalQ(cl, suppressPackageStartupMessages(library(pkg)))`
#'  * `clusterEvalQ(cl, library(pkg, character.only = TRUE))`
#'
#' The packages are recorded and attached by all following futures,
#' similarly to how `future(..., packages = pkgs)` works.
#' For all other expressions, including those that mix `library()`
#' calls with other code, are ignored and an error is produced.
#' The error can be de-escalated to a warning by setting R option
#' `future.ClusterFuture.clusterEvalQ` to `"warning"`.
#'
#' Note that the packages are not attached when `clusterEvalQ()` is
#' called, but when the futures are evaluated. This means that
#' package-loading errors are deferred to `parLapply()` etc.
#'
#' @section Benefits of using makeClusterFuture():
#' 
#' Many packages rely on traditional **parallel** functions such as
#' `parallel::parLapply()` and `parallel::clusterApply()`. Some of them
#' expose arguments (e.g. `cl` or `cluster`), or supports
#' `parallel::getDefaultCluster()`, for using a custom **parallel**
#' `cluster` object. The `makeClusterFuture()` function brings the all
#' benefits of the future ecosystem to those packages and functions.
#' 
#' One benefit is that you can use _any_ future parallel backend,
#' e.g. `plan(multisession)`, `plan(future.mirai::mirai_multisession)`,
#' `plan(future.batchtools::batchtools_slurm)`.
#' 
#' Another benefit is that output, messages, warnings, and other types of
#' conditions produced on parallel workers are automatically relayed in
#' the main R session. This can be very helpful for progress reporting
#' and troubleshooting. Among all parallel frameworks in R, only the
#' future ecosystem does this.
#'
#' @aliases FUTURE
#' @keywords internal
#' 
#' @importFrom future nbrOfWorkers
#' @rawNamespace if (getRversion() >= "4.4") export(makeClusterFuture)
makeClusterFuture <- function(specs = nbrOfWorkers(), ...) {
  stop_if_not(length(specs) == 1L)

  backend <- plan("backend")
  n <- nbrOfWorkers(backend)
  if (is.na(specs)) specs <- n

  if (is.numeric(specs)) {
    if (specs <= 0) {
      stop("Argument 'specs' must be a positive integer: %s", specs)
    }
    if (specs != n) {
      stop(sprintf("Value of argument 'specs' does not match the number of workers in the registered future backend (%s:%s): %g != %g", class(backend)[1], backend[["uuid"]], specs, n))
    }
  } else {
    stop("Unknown type of argument 'specs': ", typeof(specs))
  }
  
  options <- list(...)
  opts <- getOption("future.disposable", NULL)
  if (length(opts) > 0) {
    options <- c(options, opts)
    if (!identical(attr(opts, "dispose"), FALSE)) {
      options(future.disposable = NULL)
    }
  }
  
  if (length(options) > 0L) {
    names <- names(options)
    if (is.null(names) || !all(nzchar(names))) {
      stop("All arguments must be named")
    }
  }
  if (is.null(options[["globals"]])) {
    options[["globals"]] <- formals(future)[["globals"]]
  }

  env <- new.env(parent = emptyenv())
  env[["backend"]] <- backend
  
  cl <- vector("list", length = n)
  for (kk in seq_along(cl)) {
    node <- new.env(parent = emptyenv())
    node[["index"]] <- kk
    node[["options"]] <- options
    node[["backend"]] <- backend
    node[["cluster_env"]] <- env
    class(node) <- c("FutureNode")
    cl[[kk]] <- node
  }
  attr(cl, "cluster_env") <- env
  class(cl) <- c("FutureCluster", "cluster")
  env[["cluster"]] <- cl
  cl
}


#' @rawNamespace if (getRversion() >= "4.4") S3method(print,FutureCluster)
print.FutureCluster <- function(x, ...) {
  cat(sprintf("A %s cluster with %d node\n", sQuote(class(x)[1]), length(x)))

  cluster_env <- attr(x, "cluster_env")
  exports <- cluster_env[["exports"]]
  names <- names(exports)
  types <- vapply(exports, FUN.VALUE = NA_character_, FUN = typeof)
  info <- sprintf("%s (%s)", names, types)
  cat(sprintf("Exports: [n=%d] %s\n", length(exports), comma(info)))

  packages <- cluster_env[["packages"]]
  cat(sprintf("Packages: [n=%d] %s\n", length(packages), commaq(packages)))

  clusterEvalQs <- cluster_env[["clusterEvalQs"]]
  n <- length(clusterEvalQs)
  if (n > 0) {
    cat(sprintf("clusterEvalQ() calls ignored: [n=%d]:\n", n))
    if (n > 3) clusterEvalQs <- clusterEvalQs[1:3]
    exprs <- lapply(clusterEvalQs, FUN = function(x) {
      expr <- x[["expression"]]
      attributes(expr) <- NULL
      expr
    })
    str(exprs)
  }

  backend <- cluster_env[["backend"]]
  print(backend)

  plan_backend <- plan("backend")
  if (!identical(plan_backend[["uuid"]], backend[["uuid"]])) {
    warning(FutureWarning(
      sprintf("This %s cluster was set up under a future backend (%s:%s) that is not compatible with the current future backend (%s:%s). Make sure that the backend was not re-configured since this cluster was created", class(x)[1], class(backend)[1], backend[["uuid"]], class(plan_backend)[1], plan_backend[["uuid"]])
    ), call. = FALSE, immediate. = TRUE)
  }
}


#' @export
`[.FutureCluster` <- function(x, ...) {
  ## Subset, but drop class to make sure it's not a valid 'cluster' object
  .subset(x, ...)
}

#' @export
`[[.FutureCluster` <- function(x, ...) {
  NextMethod()
}


#' @importFrom future future
#' @rawNamespace if (getRversion() >= "4.4") importFrom(parallel,sendData)
#' @rawNamespace if (getRversion() >= "4.4") S3method(sendData,FutureNode)
sendData.FutureNode <- function(node, data) {
  ## sendCall(con, fcn, args, return = TRUE, tag = NULL)
  ##  postNode(con, "EXEC", value = list(fun = fun, args = args, return = return, tag = tag), tag = NULL)
  ##   sendData(con, data = list(type = type, data = value, tag = tag))
  ##
  ## => sendData(con, data = list(type = "EXEC", data = list(fun = fun, args = args, return = TRUE), tag = NULL))
  
  index <- node[["index"]]
  
  debug <- isTRUE(getOption("future.debug"))
  if (debug) {
    mdebugf_push("sendData() for %s #%d ...", class(node)[1], index)
    on.exit(mdebug_pop())
  }

  type <- data[["type"]]
  if (debug) mdebugf("| type: %s", sQuote(type))

  ## Assert that future backend has not changed
  backend <- node[["cluster_env"]][["backend"]]
  plan_backend <- plan("backend")
  if (!identical(plan_backend[["uuid"]], backend[["uuid"]])) {
    stop(FutureError(
      sprintf("This %s node was set up under a future backend (%s:%s) that is not compatible with the current future backend (%s:%s). Make sure that the backend was not re-configured since this cluster was created", class(node)[1], class(backend)[1], backend[["uuid"]], class(plan_backend)[1], plan_backend[["uuid"]])
    ))
  }

  if (type == "EXEC") {
    data <- data[["data"]]

    ## SPECIAL CASE #1: Called via clusterSetRNGStream()?
    if (called_via_clusterSetRNGStream()) {
      if (debug) mdebug("Detected: clusterSetRNGStream()")
      args <- data[["args"]]
      call <- args[[1]]
      seed <- call[[3]]
      if (debug) mdebugf("Seed recorded: (%s)", comma(seed))
      ns <- getNamespace("future")
      is_lecyer_cmrg_seed <- get("is_lecyer_cmrg_seed", mode = "function", envir = ns, inherits = FALSE)
      stopifnot(is_lecyer_cmrg_seed(seed))
      node[["seed"]] <- seed
      ConstantFuture <- get("ConstantFuture", mode = "function", envir = ns, inherits = FALSE)
      ## parallel:::recvResult() expects element 'value'
      node[["future"]] <- ConstantFuture(list(value = NULL), seed = seed, substitute = FALSE)
      return(invisible(node))
    } 

    ## SPECIAL CASE #2: Called via clusterExport()?
    if (called_via_clusterExport()) {
      if (debug) mdebug("Detected: clusterExport()")

      ## Only need to be handled once per cluster - not once per node
      if (index == 1L) {
        args <- data[["args"]]
        if (debug) mdebugf("Exports: [n=%d] %s", length(args), commaq(names(args)))
        cluster_env <- node[["cluster_env"]]
        exports <- cluster_env[["exports"]]
        if (is.null(exports)) exports <- list()
        ## Append <name>=<value> to 'exports'
        name <- args[[1]]
        value <- args[[2]]
        exports[[name]] <- value
        cluster_env[["exports"]] <- exports
      }

      ns <- getNamespace("future")
      ConstantFuture <- get("ConstantFuture", mode = "function", envir = ns, inherits = FALSE)
      ## parallel:::recvResult() expects element 'value'
      node[["future"]] <- ConstantFuture(list(value = NULL), substitute = FALSE)
      return(invisible(node))
    }

    ## SPECIAL CASE #3: Called via clusterEvalQ()?
    if (called_via_clusterEvalQ()) {
      if (debug) mdebug("Detected: clusterEvalQ()")

      ## Only need to be handled once per cluster - not once per node
      if (index == 1L) {
        args <- data[["args"]]
        expr <- args[[1]]
        calls <- sys.calls()
        if (debug) {
          mdebug("Expression:")
          mprint(expr)
        }

        cluster_env <- node[["cluster_env"]]

        ## Does the expression only attach packages? If so, record
        ## them so that they are attached by all futures created
        pkgs <- parse_attach_packages(expr, envir = cluster_env[["exports"]])
        if (!is.null(pkgs)) {
          if (debug) mdebugf("Packages recorded: [n=%d] %s", length(pkgs), commaq(pkgs))
          cluster_env[["packages"]] <- unique(c(cluster_env[["packages"]], pkgs))
          node[["future"]] <- ConstantFuture(list(value = NULL), substitute = FALSE)
          return(invisible(node))
        }

        ## Record ignored clusterEvalQ() expressions
        clusterEvalQs <- cluster_env[["clusterEvalQs"]]
        if (is.null(clusterEvalQs)) clusterEvalQs <- list()
        call <- list(expression = expr, calls = calls)
        clusterEvalQs <- c(clusterEvalQs, list(call))
        cluster_env[["clusterEvalQs"]] <- clusterEvalQs
  
        ## Warn about ignored clusterEvalQ() call?
        action <- getOption("future.ClusterFuture.clusterEvalQ", "error")
        if (action != "ignore") {
          cluster <- cluster_env[["cluster"]]
          code <- deparse(expr)
          code <- paste(code, collapse = " ")
          code <- substring(code, first = 1L, last = 30L)
          code <- gsub(" +", " ", code)
          msg <- sprintf("parallel::clusterEvalQ() is not supported by %s clusters. Ignoring expression: %s", class(cluster)[[1]], code)
          if (action == "warning") {
            warning(FutureWarning(msg))
          } else if (action == "error") {
            stop(FutureError(msg))
          }
        }
      }
      
      node[["future"]] <- ConstantFuture(list(value = NULL), substitute = FALSE)
      return(invisible(node))
    }

    options <- node[["options"]]
    if ("seed" %in% names(node)) {
      options[["seed"]] <- node[["seed"]]
    }

    cluster_env <- node[["cluster_env"]]
    exports <- cluster_env[["exports"]]
    if (length(exports) > 0) {
      globals <- options[["globals"]]
      if (is.logical(globals)) {
        attr(globals, "add") <- c(exports, attr(globals, "add"))
      } else if (is.character(globals)) {
        attr(globals, "add") <- c(exports, attr(globals, "add"))
      } else if (is.list(globals)) {
        globals <- c(exports, globals)
      }
      options[["globals"]] <- globals
    }

    packages <- cluster_env[["packages"]]
    if (length(packages) > 0) {
      options[["packages"]] <- unique(c(packages, options[["packages"]]))
    }

    node[["future"]] <- local({
      if (debug) {
        mdebug_push("Create future ...")
        on.exit(mdebug_pop())
        mstr(list(data = data))
        mstr(list(options = options))
      }
      fun <- data[["fun"]]
      args <- data[["args"]]

      ## Ensure 'fun' and 'args' are always available on the worker
      globals <- options[["globals"]]
      required_globals <- list(fun = fun, args = args)
      if (is.null(globals)) {
        globals <- required_globals
      } else if (is.logical(globals) || is.character(globals)) {
        attr(globals, "add") <- c(required_globals, attr(globals, "add"))
      } else if (is.list(globals)) {
        globals <- c(required_globals, globals)
      }
      options[["globals"]] <- globals

      ## quote(..., quote = TRUE) is needed in order to avoid evaluating
      ## language object (e.g. call, symbol, formula, ...) here
      expr <- quote(do.call(fun, args = args, quote = TRUE))
      future_args <- list(expr = quote(expr), substitute = FALSE)
      future_args <- c(future_args, options)

      if (debug) mstr(list(future_args = future_args))
      do.call(future, args = future_args)
    })
  } else if (type == "DONE") {
    future <- node[["future"]]
    if (inherits(future, "Future")) {
      node[["future"]] <- local({
        if (debug) {
          mdebug_push("Canceling future ...")
          on.exit(mdebug_pop())
        }
        future <- cancel(future)
        tryCatch(resolve(future), error = identity)
        tryCatch(value(future), error = identity)
        NULL
      })
    }
  } else {
    stop(sprintf("sendData() for %s: type = %s is not supported", class(node)[1], sQuote(type)))
  }
  
  invisible(node)
}


#' @importFrom future value
#' @rawNamespace if (getRversion() >= "4.4") importFrom(parallel,recvData)
#' @rawNamespace if (getRversion() >= "4.4") S3method(recvData,FutureNode)
recvData.FutureNode <- function(node) {
  debug <- isTRUE(getOption("future.debug"))
  if (debug) {
    mdebugf_push("recvData() for %s ...", class(node)[1])
    on.exit(mdebug_pop())
  }

  future <- node[["future"]]
  if (!inherits(future, "Future")) {
    stop(sprintf("%s does not have a future associated with it", class(node)[1]))
  }
  result <- result(future)
  if (debug) mprint(result)
  
  if ("seed" %in% names(node) && !is.null(result[["seed"]])) {
    if (debug) mdebug("Updating the node's RNG state")
    node[["seed"]] <- result[["seed"]]
  }

  ## Handle errors like parallel:::workCommand()
  handler <- function(e) {
    structure(conditionMessage(e), class = c("snow-try-error", "try-error"))
  }

  ## parallel:::recvResult() expects element 'value'
  list(value = tryCatch(value(future), error = handler))
}


called_via_clusterSetRNGStream <- function(calls = sys.calls()) {
  finds <- c("sendData", "postNode", "sendCall")
  nfinds <- length(finds)
  ncalls <- length(calls)
  
  ## Not possible?
  if (ncalls <= nfinds + 1L) return(FALSE)
  
  ii <- 1L
  find <- as.symbol(finds[ii])
  
  found <- FALSE
  for (jj in ncalls:1) {
    call <- calls[[jj]][[1]]

    if (identical(call, find)) {
      if (ii == nfinds) {
        ## First passage done
        found <- TRUE
        break
      }
      ii <- ii + 1L
      find <- as.symbol(finds[ii])
    } else if (ii > 1L) {
      return(FALSE)
    }
  }
  if (!found) return(FALSE)
  jj <- jj - 1L

  call <- calls[[jj]][[1]]
  if (identical(call, as.symbol("clusterSetRNGStream"))) {
    return(TRUE)
  }
  if (identical(call, quote(parallel::clusterSetRNGStream))) {
    return(TRUE)
  }
  FALSE
} ## called_via_clusterSetRNGStream()




# Dotted pair list of 6
#  $ : language clusterExport(cl, varlist = c("a", "b"))
#  $ : language clusterCall(cl, gets, name, get(name, envir = envir))
#  $ : language sendCall(cl[[i]], fun, list(...))
#  $ : language postNode(con, "EXEC", list(fun = fun, args = args, return = return, tag = tag))
#  $ : language sendData(con, list(type = type, data = value, tag = tag))
#  $ : language sendData.FutureNode(con, list(type = type, data = value, tag = tag))
called_via_clusterExport <- function(calls = sys.calls()) {
  finds <- c("sendData", "postNode", "sendCall", "clusterCall")
  nfinds <- length(finds)
  ncalls <- length(calls)
  
  ## Not possible?
  if (ncalls <= nfinds + 1L) return(FALSE)

  ii <- 1L
  find <- as.symbol(finds[ii])
  
  found <- FALSE
  for (jj in ncalls:1) {
    call <- calls[[jj]][[1]]

    if (identical(call, find)) {
      if (ii == nfinds) {
        ## First passage done
        found <- TRUE
        break
      }
      ii <- ii + 1L
      find <- as.symbol(finds[ii])
    } else if (ii > 1L) {
      return(FALSE)
    }
  }
  if (!found) return(FALSE)
  jj <- jj - 1L

  call <- calls[[jj]][[1]]
  if (identical(call, as.symbol("clusterExport"))) {
    return(TRUE)
  }
  if (identical(call, quote(parallel::clusterExport))) {
    return(TRUE)
  }
  FALSE
} ## called_via_clusterExport()


# Dotted pair list of 6
#  $ : language clusterEvalQ(cl, 42)
#  $ : language clusterCall(cl, eval, substitute(expr), envir = .GlobalEnv)
#  $ : language sendCall(cl[[i]], fun, list(...))
#  $ : language postNode(con, "EXEC", list(fun = fun, args = args, return = return, tag = tag))
#  $ : language sendData(con, list(type = type, data = value, tag = tag))
#  $ : language sendData.FutureNode(con, list(type = type, data = value, tag = tag))
called_via_clusterEvalQ <- function(calls = sys.calls()) {
  finds <- c("sendData", "postNode", "sendCall", "clusterCall")
  nfinds <- length(finds)
  ncalls <- length(calls)
  
  ## Not possible?
  if (ncalls <= nfinds + 1L) return(FALSE)

  ii <- 1L
  find <- as.symbol(finds[ii])
  
  found <- FALSE
  for (jj in ncalls:1) {
    call <- calls[[jj]][[1]]

    if (identical(call, find)) {
      if (ii == nfinds) {
        ## First passage done
        found <- TRUE
        break
      }
      ii <- ii + 1L
      find <- as.symbol(finds[ii])
    } else if (ii > 1L) {
      return(FALSE)
    }
  }
  if (!found) return(FALSE)
  jj <- jj - 1L

  call <- calls[[jj]][[1]]
  if (identical(call, as.symbol("clusterEvalQ"))) {
    return(TRUE)
  }
  if (identical(call, quote(parallel::clusterEvalQ))) {
    return(TRUE)
  }
  FALSE
} ## called_via_clusterEvalQ()


## Parses a clusterEvalQ() expression and returns the package names
## attached. This is only done if the expression uses basic library()
## and require() calls, e.g. `library(pkg)`,
## `{ library(pkg1); base::library("pkg2") }`, and
## `library(pkg, character.only = TRUE)`.
## Such calls wrapped in `invisible()`, `suppressMessages()`, and
## `suppressPackageStartupMessages()` are also accepted.
## If the expression cannot be parsed this way, NULL is returned.
parse_attach_packages <- function(expr, envir = NULL) {
  pkgs <- character(0L)

  parse_expr <- function(expr) {
    if (!is.call(expr)) return(FALSE)

    fcn <- expr[[1]]
    ## Drop 'base::' prefix
    if (is.call(fcn) && identical(fcn[[1]], as.symbol("::")) &&
        identical(fcn[[2]], as.symbol("base"))) {
      fcn <- fcn[[3]]
    }
    if (!is.symbol(fcn)) return(FALSE)
    name <- as.character(fcn)

    if (name == "{") {
      exprs <- as.list(expr)[-1]
      for (expr in exprs) {
        if (!parse_expr(expr)) return(FALSE)
      }
      return(TRUE)
    }

    if (name %in% c("(", "invisible", "suppressMessages", "suppressPackageStartupMessages")) {
      if (length(expr) != 2L || !is.null(names(expr))) return(FALSE)
      return(parse_expr(expr[[2]]))
    }

    if (name == "library") {
      def <- base::library
    } else if (name == "require") {
      def <- base::require
    } else {
      return(FALSE)
    }

    call <- tryCatch(match.call(def, call = expr), error = function(e) NULL)
    if (is.null(call)) return(FALSE)
    args <- as.list(call)[-1]

    ## Arguments, e.g. 'lib.loc' and 'help', that affect what is attached
    ## are not supported
    known <- c("package", "character.only", "quietly", "warn.conflicts", "verbose", "logical.return")
    if (!all(names(args) %in% known)) return(FALSE)

    character_only <- args[["character.only"]]
    if (is.null(character_only)) character_only <- FALSE
    if (!is.logical(character_only) || length(character_only) != 1L ||
        is.na(character_only)) return(FALSE)

    pkg <- args[["package"]]
    if (is.null(pkg)) return(FALSE)
    if (is.symbol(pkg)) {
      pkg <- as.character(pkg)
      if (character_only) {
        if (!pkg %in% names(envir)) return(FALSE)
        pkg <- envir[[pkg]]
      }
    }
    if (!is.character(pkg) || length(pkg) != 1L ||
        is.na(pkg) || !nzchar(pkg)) return(FALSE)

    pkgs <<- c(pkgs, pkg)
    TRUE
  } ## parse_expr()

  res <- parse_expr(expr)

  ## Non-supported clusterEvalQ() expression?
  if (!res) return(NULL)

  ## No packages attached?
  if (length(pkgs) == 0L) return(NULL)

  unique(pkgs)
} ## parse_attach_packages()
